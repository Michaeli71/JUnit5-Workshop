package a_questions;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.time.LocalDate;
import java.util.Arrays;

import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.converter.ConvertWith;
import org.junit.jupiter.params.converter.SimpleArgumentConverter;
import org.junit.jupiter.params.provider.CsvSource;

/**
 * Beispielprogramm für den Workshop "JUnit 5"
 * 
 * @author Michael Inden
 * 
 * Copyright 2019 by Michael Inden 
 */
public class MultipleArgumentToParamObjectConverterTest
{
    @ParameterizedTest
    @CsvSource({ "Peter    | Lustig | 2012-12-06, 52070 | Aachen, 1|2|3, Lustig, 2012-12-06", 
                 "Michael   | Inden | 1971-02-07, 8047 |Zürich, 7|2|1|14|49, Inden, 1971-02-07",
                 "Jeff |  Miller   | 2014-09-09, 24107| Kiel, 7|2|1|14|49, Miller, 2014-09-09" })
    void jsonPersonAdultTest(@ConvertWith(SimplePersonDtoConverter.class) SimplePersonDto person,
                             @ConvertWith(SimpleAddressDtoConverter.class) SimpleAddressDto address,
                             @ConvertWith(SimpleIntArrayConverter.class) int[] values,
                             String expectedLastName, LocalDate expectedDateOfBirth)
    {        
        assertTrue(person.lastName.toLowerCase().contains("i"));
        assertTrue(address.zipCode > 5000);
        
        assertEquals(expectedLastName, person.lastName);
        assertEquals(expectedDateOfBirth, person.dateOfBirth);
        
        System.out.println(person.lastName + " int values: " + Arrays.toString(values));
    }

    static class SimplePersonDto
    {
        String    firstName;
        String    lastName;
        LocalDate dateOfBirth;

        public SimplePersonDto(String firstName, String lastName, LocalDate dateOfBirth)
        {
            this.firstName = firstName;
            this.lastName = lastName;
            this.dateOfBirth = dateOfBirth;
        }
    }

    static class SimpleAddressDto
    {
        int    zipCode;
        String city;

        public SimpleAddressDto(int zipCode, String city)
        {
            this.zipCode = zipCode;
            this.city = city;
        }               
    }
    
    static class SimplePersonDtoConverter extends SimpleArgumentConverter
    {
        @Override
        public SimplePersonDto convert(Object source, Class<?> targetType)
        {
            System.out.println("s1: " + source);
            String[] values = extractValues(source);          
            
            return new SimplePersonDto(values[0], values[1], LocalDate.parse(values[2]));
        }
    }

    static class SimpleAddressDtoConverter extends SimpleArgumentConverter
    {
        @Override
        public SimpleAddressDto convert(Object source, Class<?> targetType)
        {
            System.out.println("s2: " + source);
            String[] values = extractValues(source);
            
            return new SimpleAddressDto(Integer.valueOf(values[0]), values[1]);
        }
    }
    
    static class SimpleIntArrayConverter extends SimpleArgumentConverter
    {
        @Override
        public int[] convert(Object source, Class<?> targetType)
        {
            System.out.println("s3: " + source);
            String[] values = extractValues(source);
            
            /*
            int[] intValues = new int[values.length];
            for (int i = 0; i < values.length; i++)
            {
                intValues[i] = Integer.valueOf(values[i]);
            }
            
            return intValues;
            */
            
            // Java 8 Alternative
            return Arrays.stream(values).mapToInt(val -> Integer.valueOf(val)).toArray();
        }
    }
    
    private static String[] extractValues(Object source)
    {
        String sourceAsText = (String) source;
        String sourceAsTextNoSpaces = sourceAsText.replaceAll("(\\s)*", "");
        String[] values = sourceAsTextNoSpaces.split("\\|");
        
        return values;
    }
}
