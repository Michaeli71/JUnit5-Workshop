package a_questions;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.stream.Stream;

import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;

/**
 * Beispielprogramm für den Workshop "JUnit 5"
 * 
 * @author Michael Inden
 * 
 * Copyright 2019 by Michael Inden 
 */
public class AdderEdgeCasesTest
{
    @ParameterizedTest(name = "{0} + {1} = {2}")
    @MethodSource("specialValues")
    void testSilentOverflow(int value, int offset, int expected)
    {
        assertEquals(expected, value + offset);
    }
    
    static Stream<Arguments> specialValues()
    {
        return Stream.of(Arguments.of(Integer.MAX_VALUE, 7, Integer.MIN_VALUE + 6),
                         Arguments.of(Integer.MIN_VALUE, -7, Integer.MAX_VALUE - 6),
                         Arguments.of(Integer.MAX_VALUE, Integer.MIN_VALUE, -1));
    }
    
    // nicer
    
    @ParameterizedTest(name = "{3} ...... Details: {0} + {1} = {2}")
    @MethodSource("specialValues_V2")
    void testSilentOverflow_V2(int value, int offset, int expected, String hint)
    {
        assertEquals(expected, value + offset);
    }
    
    static Stream<Arguments> specialValues_V2()
    {
        return Stream.of(Arguments.of(Integer.MAX_VALUE, 7, Integer.MIN_VALUE + 6, "Integer.MAX_VALUE + 7 = Integer.MIN_VALUE + 6"),
                         Arguments.of(Integer.MIN_VALUE, -7, Integer.MAX_VALUE - 6, "Integer.MIN_VALUE -7 = Integer.MAX_VALUE - 6"),
                         Arguments.of(Integer.MAX_VALUE, Integer.MIN_VALUE, -1, "Integer.MAX_VALUE + Integer.MIN_VALUE = -1"));
    }
}
