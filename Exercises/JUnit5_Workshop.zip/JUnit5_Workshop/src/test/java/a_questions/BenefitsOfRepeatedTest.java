package a_questions;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.RepeatedTest;
import org.junit.jupiter.api.RepetitionInfo;
import org.junit.jupiter.api.TestInfo;

/**
 * Beispielprogramm für den Workshop "JUnit 5"
 * 
 * @author Michael Inden
 * 
 * Copyright 2019 by Michael Inden 
 */
public class BenefitsOfRepeatedTest
{
    @RepeatedTest(value = 10, name = "{displayName} {currentRepetition}/{totalRepetitions}")
    @DisplayName("Repeated! ")
    void customDisplayName(TestInfo testInfo, RepetitionInfo repetitionInfo)
    {
        int current = repetitionInfo.getCurrentRepetition();
        int total = repetitionInfo.getTotalRepetitions();

        // Simulate flacky test
        if (Math.random() < 0.5)
            assertEquals(testInfo.getDisplayName(), "Repeated! " + current + "/" + total);
        else
            assertTrue(false);
    }
}
