package x_slides.part2_junit5_intro;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.Arrays;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInfo;

/**
 * Beispielprogramm für den Workshop "JUnit 5"
 * 
 * @author Michael Inden
 * 
 * Copyright 2019 by Michael Inden 
 */
public class G_TestInfo
{
    @Test
    void simpleTestInfo(TestInfo ti)
    {
        assertEquals("simpleTestInfo", ti.getTestMethod().get().getName());
    }

    @Test
    @DisplayName("DEMO-TAGS")
    @Tag("FAST")
    @Tag("COOL")
    void moreTestInfo(TestInfo ti)
    {
        assertEquals("DEMO-TAGS", ti.getDisplayName());
        assertEquals(Arrays.asList("FAST", "COOL"), ti.getTags());
    }
}