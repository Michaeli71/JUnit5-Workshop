package x_slides.part2_junit5_intro;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

/**
 * Beispielprogramm für den Workshop "JUnit 5"
 * 
 * @author Michael Inden
 * 
 * Copyright 2019 by Michael Inden 
 */
@DisplayName("REST product controller")
public class C_DisplayNameDemo
{

  @Test
  @DisplayName("GET 'http://localhost:8080/products/4711' user: Peter Müller")
  public void getProductFor4711() 
  {
      // ..
  }

  @Test
  @DisplayName("POST 'http://localhost:8080/products/' user: Stock Manager")
  public void addProductAsStockManager() 
  {
      // ...
  }
}