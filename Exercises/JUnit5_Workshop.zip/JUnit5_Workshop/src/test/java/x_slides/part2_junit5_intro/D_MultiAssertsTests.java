package x_slides.part2_junit5_intro;

import static org.junit.jupiter.api.Assertions.assertAll;
import static org.junit.jupiter.api.Assertions.assertEquals;

import java.time.LocalDate;

import org.junit.jupiter.api.Test;

import domain.Person;

/**
 * Beispielprogramm für den Workshop "JUnit 5"
 * 
 * @author Michael Inden
 * 
 * Copyright 2019 by Michael Inden 
 */
public class D_MultiAssertsTests
{
    @Test
    void multipleAssertsforOneTopic()
    {
        final Person mike = new Person("Mike", LocalDate.of(1971, 2, 7), "Zürich");

        // JUnit 4 
        assertEquals("Mike", mike.name);
        assertEquals(LocalDate.of(1971, 2, 7), mike.dateOfBirth);
        assertEquals("Zürich", mike.homeTown);

        // JUnit 5
        assertAll(() -> assertEquals("Mike", mike.name), 
                  () -> assertEquals(LocalDate.of(1971, 2, 7), mike.dateOfBirth),
                  () -> assertEquals("Zürich", mike.homeTown));
    }

    // wo liegt der Unterschied ...
    @Test
    void multipleAssertsforOneTopic_Diff1()
    {
        final Person mike = new Person("Mike", LocalDate.of(1971, 2, 7), "Zürich");

        // JUnit 4 
        assertEquals("Tim", mike.name);
        assertEquals(LocalDate.of(1971, 3, 27), mike.dateOfBirth);
        assertEquals("Kiel", mike.homeTown);
    }

    @Test
    void multipleAssertsforOneTopic_Diff2()
    {

        final Person mike = new Person("Mike", LocalDate.of(1971, 2, 7), "Zürich");

        // JUnit 5
        assertAll(() -> assertEquals("Tim", mike.name), 
                  () -> assertEquals(LocalDate.of(1971, 3, 27), mike.dateOfBirth),
                  () -> assertEquals("Kiel", mike.homeTown));
    }
}
