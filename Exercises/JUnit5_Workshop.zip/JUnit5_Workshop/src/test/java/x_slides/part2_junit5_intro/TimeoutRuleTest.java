package x_slides.part2_junit5_intro;

import java.util.concurrent.TimeUnit;

import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.Timeout;

/**
 * Beispielprogramm für den Workshop "JUnit 5"
 * 
 * @author Michael Inden
 * 
 * Copyright 2019 by Michael Inden 
 */
public class TimeoutRuleTest
{
    @Rule
    public Timeout timeout = new Timeout(500, TimeUnit.MILLISECONDS);

    @Test
    public void longRunningAction() throws InterruptedException
    {
        for (int i = 0; i < 20; i++)
        {
            TimeUnit.SECONDS.sleep(1);
        }
    }

    @Test
    public void loopForever() throws InterruptedException
    {
        for (;;)
        {
            TimeUnit.SECONDS.sleep(1);
        }
    }
}