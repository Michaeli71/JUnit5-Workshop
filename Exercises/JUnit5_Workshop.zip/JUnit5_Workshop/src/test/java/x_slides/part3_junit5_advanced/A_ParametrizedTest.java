package x_slides.part3_junit5_advanced;

import static org.junit.Assert.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.junit.jupiter.params.provider.ValueSource;

import utils.PalindromeChecker;

/**
 * Beispielprogramm für den Workshop "JUnit 5"
 * 
 * @author Michael Inden
 * 
 * Copyright 2019 by Michael Inden 
 */
public class A_ParametrizedTest
{
    @ParameterizedTest
    @ValueSource(strings = { "Otto", "Radar" })
    void palindromes(String candidate)
    {
        boolean isPalindrome = PalindromeChecker.isPalindrome(candidate);

        assertTrue(isPalindrome);
    }

    @ParameterizedTest
    @CsvSource({ "Otto,true", "Radar,true", "Dummy,false" })
    void palindromes2(String candidate, boolean expected)
    {
        boolean isPalindrome = PalindromeChecker.isPalindrome(candidate);

        assertEquals(expected, isPalindrome);
    }

    // Werteangaben
    @ParameterizedTest
    @CsvSource({ "test,TEST", "tEst,TEST", "Java,JAVA" })
    void toUpperCase_ShouldGenerateTheExpectedUppercase(String input, String expected)
    {
        String actualValue = input.toUpperCase();

        assertEquals(expected, actualValue);
    }

    // Multiple values
    @ParameterizedTest
    @CsvSource({ "MI,CHA,MICHA", "TI,M,TIM", "JA,VA,JAVA" })
    void concat_ShouldCombineValues(String input1, String input2, String expected)
    {
        String actualValue = input1.concat(input2);

        assertEquals(expected, actualValue);
    }

    // Multiple values, different types
    @ParameterizedTest
    @CsvSource({ "MI,CHA,5", "TI,M,3", "JA,VA,4" })
    void concat_ShouldCombineValues_DifferentTypes(String input1, String input2, int expectedLength)
    {
        int actualValue = input1.concat(input2).length();
        
        assertEquals(expectedLength, actualValue);
    }

    // Better naming 
    @ParameterizedTest(name = "{0} + {1} should have length {2}")
    @CsvSource({ "MI,CHA,5", "TI,M,3", "JA,VA,4" })
    void concat_ShouldCombineValues_DifferentTypes_And_Name(String input1, String input2, int expectedLength)
    {
        int actualValue = input1.concat(input2).length();

        assertEquals(expectedLength, actualValue);
    }

    @ParameterizedTest(name = "{index}: {0} has length 3")
    @ValueSource(strings = { "tim", "tom", "abc" })
    void allHaveLengthOf3(String input)
    {
        assertEquals(3, input.length());
    }

    @ParameterizedTest(name = "{index}: {0} + {1} = {2}")
    @CsvSource({ "1,1,2", "2,5,7", "7,-7,0" })
    void addition(int a, int b, int result)
    {
        int sum = a + b;

        assertEquals(result, sum);
    }
}
