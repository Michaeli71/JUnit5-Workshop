package x_slides.part3_junit5_advanced;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.NoSuchElementException;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;

/**
 * Beispielprogramm für den Workshop "JUnit 5"
 * 
 * @author Michael Inden
 * 
 * Copyright 2019 by Michael Inden 
 */
// Siehe https://www.viadee.de/wp-content/uploads/JUnit5_javaspektrum.pdf
public class C_NestedOptionalTest
{
    @Nested
    @DisplayName("Testfälle für ein leeres Optional")
    class EmptyOptionalTest
    {
        private Optional<String> emptyOptional;

        @BeforeEach
        void setUp()
        {
            emptyOptional = Optional.empty();
        }

        @Test
        @DisplayName("Optional.isPresent() liefert false")
        void isPresent()
        {
            assertFalse(emptyOptional.isPresent());
        }

        @Test
        @DisplayName("Optional.get() liefert Exception")
        void get()
        {
            assertThrows(NoSuchElementException.class, emptyOptional::get);
        }
    }

    @Nested
    @DisplayName("Testfälle für ein vorhandenes Optional")
    class PresentOptionalTest
    {
        private static final String JUGS = "JUGS";

        private Optional<String>    presentOptional;

        @BeforeEach
        void setUp()
        {
            presentOptional = Optional.of(JUGS);
        }

        @Test
        @DisplayName("Optional.isPresent() liefert true")
        void isPresent()
        {
            assertTrue(presentOptional.isPresent());
        }

        @Test
        @DisplayName("Optional.get() liefert den Wert")
        void get()
        {
            assertEquals(JUGS, presentOptional.get());
        }
    }
}