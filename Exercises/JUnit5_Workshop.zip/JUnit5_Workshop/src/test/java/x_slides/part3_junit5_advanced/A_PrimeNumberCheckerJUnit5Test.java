package x_slides.part3_junit5_advanced;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;

import utils.PrimeNumberChecker;

/**
 * Beispielprogramm für den Workshop "JUnit 5"
 * 
 * @author Michael Inden
 * 
 * Copyright 2019 by Michael Inden 
 */
public class A_PrimeNumberCheckerJUnit5Test 
{
	@ParameterizedTest(name = "{0} is prime {1}")
	@CsvSource({"2,true", "3,true", "6, false", "11,true", "14,false"})
	void testIsprime(int value, boolean expected) 
	{
		assertEquals(expected, PrimeNumberChecker.isPrime(value));
	}
}