package x_slides.part3_junit5_advanced;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.withPrecision;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.List;
import java.util.Map;
import java.util.function.IntPredicate;

import org.junit.jupiter.api.Test;

/**
 * Beispielprogramm für den Workshop "JUnit 5"
 * 
 * @author Michael Inden
 * 
 *         Copyright 2019 by Michael Inden
 */
public class E_AssertJIntroTest
{
    @Test
    void someStringAsserts()
    {
        // JUnit style
        assertFalse("ABC".isEmpty());
        assertTrue("ONE TWO THREE".contains("TWO"));

        // AssertJ
        assertThat("ABC").isNotEmpty();
        assertThat("ONE TWO THREE").contains("TWO");
    }

    @Test
    void someNumberAsserts()
    {
        // JUnit style
        assertEquals(42, 42);
        assertEquals(3.415, 3, 0.15d);

        IntPredicate greaterThan = n -> n >= 27;
        assertTrue(greaterThan.test(42));
        assertTrue(isBetween(9, 0, 10));

        // AssertJ
        assertThat(42).isEqualTo(42);
        assertThat(3.1415).isEqualTo(3, withPrecision(0.15d));
        assertThat(3.1415).isCloseTo(3, withPrecision(0.15d));
        assertThat(42).isGreaterThanOrEqualTo(27);
        assertThat(7).isBetween(0, 10);
    }

    boolean isBetween(int n, int lowerBound, int upperBound)
    {
        return n >= lowerBound && n < upperBound;
    }

    @Test
    void someListAsserts()
    {
        List<String> list = List.of("2", "3", "5", "7", "7", "11", "13");
    
        // JUnit style
        assertNotNull(list);
        assertFalse(list.isEmpty());
    
        // AssertJ
        assertThat(list).isNotNull();
        assertThat(list).isNotEmpty();
        assertThat(list).startsWith("2").contains("7").endsWith("11", "13");
    }

    @Test
    void someChainedListAsserts()
    {
        List<String> list = List.of("2", "3", "5", "7", "11", "13");

        // cool: chaining von Methoden
        assertThat(list).isNotNull().isNotEmpty().startsWith("2").contains("7");
    }

    @Test
    void someMoreListAsserts()
    {
        List<String> list = List.of("2", "3", "5", "7", "11", "13");

        assertThat(list).doesNotContain("42").containsSequence("3", "5", "7");
    }

    @Test
    void someMapAsserts()
    {
        Map<String, Integer> nameAgeMap = Map.of("Tom", 47, "Tim", 49, "Micha", 49);

        assertThat(nameAgeMap).isNotEmpty().doesNotContainKeys("John").containsKey("Tim")
                        .contains(Map.entry("Micha", 49));
    }
}
