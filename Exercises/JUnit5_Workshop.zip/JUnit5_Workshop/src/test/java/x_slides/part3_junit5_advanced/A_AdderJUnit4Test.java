package x_slides.part3_junit5_advanced;

import static org.junit.Assert.assertEquals;
import java.util.Arrays;
import java.util.Collection;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;
import org.junit.runners.Parameterized.Parameters;

import utils.Adder;

/**
 * Beispielprogramm für den Workshop "JUnit 5"
 * 
 * @author Michael Inden
 * 
 * Copyright 2019 by Michael Inden 
 */
@RunWith(Parameterized.class)
public class A_AdderJUnit4Test
{
    private int first;
    private int second;
    private int expected;

    public A_AdderJUnit4Test(int firstNumber, int secondNumber, int expectedResult)
    {
        this.first = firstNumber;
        this.second = secondNumber;
        this.expected = expectedResult;
    }

    @Parameters(name="{0} + {1} = {2}")
    public static Collection<Integer[]> inputAndExpectedNumbers()
    {
        return Arrays.asList(new Integer[][] { { 1, 2, 3 }, 
                                               { 3, -3, 0 }, 
                                               { 7, 2, 9 }, 
                                               { 7, -2, 5 }, });
    }

    @Test
    public void sum()
    {
        assertEquals(expected, Adder.add(first, second));
    }
}
