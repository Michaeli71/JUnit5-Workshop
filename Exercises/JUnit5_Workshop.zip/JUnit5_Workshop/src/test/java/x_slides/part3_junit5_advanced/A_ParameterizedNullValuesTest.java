package x_slides.part3_junit5_advanced;

import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.List;

import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.EmptySource;
import org.junit.jupiter.params.provider.NullSource;

/**
 * Beispielprogramm für den Workshop "JUnit 5"
 * 
 * @author Michael Inden
 * 
 * Copyright 2019 by Michael Inden 
 */
public class A_ParameterizedNullValuesTest {

	@ParameterizedTest(name = "test ''{0}'' for null or empty")
	@NullSource
	@EmptySource
	void nullAndEmptyStrings(String str) {
		assertTrue(str == null || str.isEmpty());
	}

	@ParameterizedTest(name = "test ''{0}'' for null or empty")
	@NullSource
	@EmptySource
	void nullAndEmptyLists(List<?> list) {
		assertTrue(list == null || list.isEmpty());
	}
}