package x_slides.part3_junit5_advanced;

import static org.assertj.core.api.Assertions.assertThatExceptionOfType;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

import java.io.IOException;

import org.assertj.core.api.ThrowableAssert.ThrowingCallable;
import org.junit.jupiter.api.Test;

/**
 * Beispielprogramm für den Workshop "JUnit 5"
 * 
 * @author Michael Inden
 * 
 *         Copyright 2019 by Michael Inden
 */
public class E_AssertJExceptionsTest
{
    @Test
    void testException()
    {
        ThrowingCallable action = () -> {
            throw new Exception("PENG!");
        };

        assertThatThrownBy(action).isInstanceOf(Exception.class).hasMessageContaining("PENG");
    }

    @Test
    void testException_2()
    {
        ThrowingCallable action = () -> {
            throw new IOException("PENG!");
        };

        assertThatExceptionOfType(IOException.class).isThrownBy(action).withMessage("%s!", "PENG")
                        .withMessageContaining("NG").withNoCause();
    }
}