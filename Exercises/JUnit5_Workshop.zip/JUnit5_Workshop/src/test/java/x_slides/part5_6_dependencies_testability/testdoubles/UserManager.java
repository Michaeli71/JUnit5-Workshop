package x_slides.part5_6_dependencies_testability.testdoubles;

/**
 * Beispielprogramm für den Workshop "JUnit 5"
 * 
 * @author Michael Inden
 * 
 * Copyright 2019 by Michael Inden 
 */
public class UserManager
{
    public void save(String userName)
    {

    }
}
