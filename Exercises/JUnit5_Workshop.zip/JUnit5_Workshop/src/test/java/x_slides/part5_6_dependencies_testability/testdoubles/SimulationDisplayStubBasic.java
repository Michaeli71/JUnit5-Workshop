package x_slides.part5_6_dependencies_testability.testdoubles;

/**
 * Beispielprogramm für den Workshop "JUnit 5"
 * 
 * @author Michael Inden
 * 
 * Copyright 2019 by Michael Inden 
 */
public final class SimulationDisplayStubBasic implements IDisplay
{
    @Override
    public void displayMsg(final MessageDto msg)
    {
        System.out.println("SimulationDisplay - got msg ’" + msg + "’");
    }
}