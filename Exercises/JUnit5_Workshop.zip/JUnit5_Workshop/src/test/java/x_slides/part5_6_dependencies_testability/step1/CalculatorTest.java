package x_slides.part5_6_dependencies_testability.step1;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

import org.junit.jupiter.api.Test;


/**
 * Beispielprogramm für den Workshop "JUnit 5"
 * 
 * @author Michael Inden
 * 
 * Copyright 2019 by Michael Inden 
 */
public class CalculatorTest
{
    @Test
    void testCalc_TwoNumbers_ShouldReturnSum()
    {
        final Calculator calculator = new Calculator();
        assertEquals(5, calculator.calc("2", "3"));
    }

    @Test
    void testCalc_WithEqualNumbersButDifferentSigns_ShouldReturn0()
    {
        final Calculator calculator = new Calculator();
        assertEquals(0, calculator.calc("7", "-7"));
    }

@Test
void testCalc_IllegalInputs_ShouldRaiseException()
{
    final Calculator calculator = new Calculator()
    {
        @Override
        protected void showWarning(final String message)
        {
            // JOptionPane.showConfirmDialog(null, message);
            // throw new IllegalArgumentException("Keine gültige Ganzzahl");
        }
    };
    
    assertThrows(IllegalArgumentException.class, () -> calculator.calc("a2", "b3"));
}
}