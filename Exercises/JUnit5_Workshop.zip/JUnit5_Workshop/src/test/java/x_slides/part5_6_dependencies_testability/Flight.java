package x_slides.part5_6_dependencies_testability;

/**
 * Beispielprogramm für den Workshop "JUnit 5"
 * 
 * @author Michael Inden
 * 
 * Copyright 2019 by Michael Inden 
 */
public class Flight
{
    public String number;
    public String airlineCode;
    public int mileage;
    public boolean isCanceled;
    
    public Flight(String validFlightNumber)
    {
        this.number = validFlightNumber;
        this.airlineCode = validFlightNumber.substring(0, 2);
    }

    public void setMileage(int miles)
    {
       this.mileage = miles;
    }

    public int getMileageAsKm() throws InvalidRequestException
    {
        if (isCanceled)
            throw new InvalidRequestException("Cannot get cancelled flight mileage");
            
        return (int) (mileage * 1.6);
    }

    public void cancel()
    {        
        isCanceled = true;
    }

}
