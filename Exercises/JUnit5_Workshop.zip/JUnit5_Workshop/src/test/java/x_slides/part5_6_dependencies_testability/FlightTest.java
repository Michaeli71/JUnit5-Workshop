package x_slides.part5_6_dependencies_testability;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

import org.junit.jupiter.api.Test;

/**
 * Beispielprogramm für den Workshop "JUnit 5"
 * 
 * @author Michael Inden
 * 
 * Copyright 2019 by Michael Inden 
 */
public class FlightTest
{
    @Test
    public void testFlightMileage_asKm2() throws Exception
    {
        // setup fixture
        String validFlightNumber = "LX 857";
        // exercise contructor
        Flight newFlight = new Flight(validFlightNumber);
        // verify constructed object
        assertEquals(validFlightNumber, newFlight.number);
        assertEquals("LX", newFlight.airlineCode);
        // setup mileage
        newFlight.setMileage(1111);
        int actualKilometres = newFlight.getMileageAsKm();
        // verify results
        int expectedKilometres = 1777;
        assertEquals(expectedKilometres, actualKilometres);
        // now try it with a canceled flight:
        newFlight.cancel();
        Throwable th = assertThrows(InvalidRequestException.class, () -> newFlight.getMileageAsKm());
        assertEquals("Cannot get cancelled flight mileage", th.getMessage());
    }
}
