package x_slides.part5_6_dependencies_testability;

/**
 * Beispielprogramm für den Workshop "JUnit 5"
 * 
 * @author Michael Inden
 * 
 * Copyright 2019 by Michael Inden 
 */
public class ItemService
{
    private final ItemRepository repository;
    
    public ItemService(final ItemRepository repository)
    {
        this.repository = repository;
    }
    
    public Item getItemById(final Long id)
    {
        return repository.findById(id);
    }
}
