package exercises.part3;

import static org.junit.Assert.assertTrue;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;

/**
 * Beispielprogramm für den Workshop "JUnit 5"
 * 
 * @author Michael Inden
 * 
 * Copyright 2019 by Michael Inden 
 */
class Ex02_MatchingBracesCheckerTest 
{
	@Test
	public void testCheckMatchingBraces_Ok_1() throws Exception 
	{
		String input = "()";
		assertTrue("Checking " + input, Ex02_MatchingBracesChecker.checkMatchingBraces(input));
	}

	// TODO
	
	@ParameterizedTest
	@ValueSource(strings = { "(()", "TODO" })
	public void testCheckMatchingBracesAllWrong_Parametrized(String current)  
	{
		// TODO
	}
}
