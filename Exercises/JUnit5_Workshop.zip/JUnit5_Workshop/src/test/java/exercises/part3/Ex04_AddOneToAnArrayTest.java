package exercises.part3;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

/**
 * Beispielprogramm für den Workshop "JUnit 5"
 * 
 * @author Michael Inden
 * 
 * Copyright 2019 by Michael Inden 
 */
public class Ex04_AddOneToAnArrayTest
{
    @Test
    @DisplayName("[1, 2, 3, 4] + 1 => [1, 2, 3, 5]")
    void testAddOne()
    {
        final int[] values = { 1, 2, 3, 4 };
        final int[] expected = { 1, 2, 3, 5 };

        final int[] result = Ex04_AddOneToAnArray.addOne(values);

        assertEquals(expected, result);
    }
}