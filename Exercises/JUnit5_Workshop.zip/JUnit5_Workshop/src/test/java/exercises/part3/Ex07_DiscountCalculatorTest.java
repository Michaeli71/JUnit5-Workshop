package exercises.part3;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

/**
 * Beispielprogramm für den Workshop "JUnit 5"
 * 
 * @author Michael Inden
 * 
 * Copyright 2019 by Michael Inden 
 */
class Ex07_DiscountCalculatorTest
{
    // Äquivalenzklassentests / Happy Path the old way ...

    @Test
    public void testCalcDiscountNo()
    {
        Ex07_DiscountCalculator calc = new Ex07_DiscountCalculator();

        int result = calc.calcDiscount(25);

        assertEquals(0, result);
    }

    @Test
    public void testCalcDiscountMedium()
    {
        Ex07_DiscountCalculator calc = new Ex07_DiscountCalculator();

        int result = calc.calcDiscount(1000);

        assertEquals(4, result);
    }

    @Test
    public void testCalcDiscountHigh()
    {
        Ex07_DiscountCalculator calc = new Ex07_DiscountCalculator();

        int result = calc.calcDiscount(2000);

        assertEquals(7, result);
    }

    // Grenzwerttests the old way ...

    @Test
    public void testCalcDiscount49()
    {
        Ex07_DiscountCalculator calc = new Ex07_DiscountCalculator();

        int result = calc.calcDiscount(49);

        assertEquals(0, result);
    }

    @Test
    public void testCalcDiscount50()
    {
        Ex07_DiscountCalculator calc = new Ex07_DiscountCalculator();

        int result = calc.calcDiscount(50);

        assertEquals(4, result);
    }

    @Test
    public void testCalcDiscount51()
    {
        Ex07_DiscountCalculator calc = new Ex07_DiscountCalculator();

        int result = calc.calcDiscount(51);

        assertEquals(4, result);
    }
}
