package exercises.part5_6;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.time.LocalDate;

import org.junit.jupiter.api.Test;

/**
 * Beispielprogramm für den Workshop "JUnit 5"
 * 
 * @author Michael Inden
 * 
 * Copyright 2019 by Michael Inden 
 */
class Ex06_DateInRomanCharsServiceTest
{
    private Ex06_DateInRomanCharsService service;

    private Arabic2RomanConverter   converter;

    @Test
    void testServiceCallForCertainDate() throws Exception
    {
        LocalDate date = LocalDate.of(1971, 2, 7);

        // TODO
        
        assertEquals("VII-II-MCMLXXI", service.getRomanDate(date));
    }
}