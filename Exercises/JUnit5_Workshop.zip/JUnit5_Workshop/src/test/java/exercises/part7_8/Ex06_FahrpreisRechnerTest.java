package exercises.part7_8;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

/**
 * Beispielprogramm für den Workshop "JUnit 5"
 * 
 * @author Michael Inden
 * 
 * Copyright 2019 by Michael Inden 
 */
public class Ex06_FahrpreisRechnerTest 
{
	private static final int grundpreis = 3_50;
	private static final int centProKM = 2_10;
	
	@Test
	public void TF1()
	{
		final int preis = FahrpreisRechner.fahrpreis(grundpreis, centProKM, 60, true, true, false);
		
		assertEquals(14_286, preis);
	}
	
	@Test
	public void TF2()
	{
		final int preis = FahrpreisRechner.fahrpreis(grundpreis, centProKM, 60, true, false, false);
		
		assertEquals(13_986, preis);
	}
}
