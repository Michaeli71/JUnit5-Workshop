package solutions.part3;

import static org.junit.jupiter.api.Assertions.assertAll;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Stream;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;

import utils.MathUtils;

/**
 * Beispielprogramm für den Workshop "JUnit 5"
 * 
 * @author Michael Inden
 * 
 * Copyright 2019 by Michael Inden 
 */
class Ex13_PermutationsTest
{
    @Test
    void testCalcPermutationsForA()
    {
        final Set<String> permutations = Ex13_Permutations.calcPermutations("A");

        assertEquals(1, permutations.size());
        assertTrue(permutations.contains("A"));
    }

    @Test
    void testCalcPermutationsForAB()
    {
        final Set<String> permutations = Ex13_Permutations.calcPermutations("AB");

        assertEquals(2, permutations.size());
        assertTrue(permutations.containsAll(Arrays.asList("AB", "BA")));
    }

    @Test
    void testCalcPermutationsForABC()
    {
        final Set<String> permutations = Ex13_Permutations.calcPermutations("ABC");

        assertEquals(6, permutations.size());
        assertTrue(permutations.containsAll(Arrays.asList("ABC", "ACB", "BAC", "BCA", "CBA", "CAB")));
    }

    @Test
    void testCalcPermutationsFor0123456789()
    {
        final String input = "0123456789";
        final int expectedSizeBasedOnFaculty = MathUtils.fac(input.length());

        final Set<String> permutations = Ex13_Permutations.calcPermutations(input);

        assertEquals(expectedSizeBasedOnFaculty, permutations.size());
        // und nun??? wie alle die Werte prüfen?? Ideen
    }

    @Test
    void testCalcPermutationsForAACAA()
    {
        final Set<String> permutations = Ex13_Permutations.calcPermutations("AACAA");

        // UPS: Wie berechnen wir das bei Duplikaten??
        assertEquals(5, permutations.size());
        assertTrue(permutations.containsAll(Arrays.asList("AACAA", "AAAAC", "ACAAA", "AAACA", "CAAAA")));
    }

    // => JUnit 5 

    @Test
    void testCalcPermutationsForA_JUnit5()
    {
        final Set<String> permutations = Ex13_Permutations.calcPermutations("A");

        assertAll(() -> assertEquals(1, permutations.size()), () -> assertTrue(permutations.contains("A")));
    }

    @Test
    void testCalcPermutationsForAB_JUnit5()
    {
        final Set<String> expected = new HashSet<>(Arrays.asList("AB", "BA"));

        final Set<String> permutations = Ex13_Permutations.calcPermutations("AB");

        assertAll(() -> assertEquals(2, permutations.size()), () -> assertEquals(expected, permutations));
    }

    @Test
    void testCalcPermutationsForABC_JUnit5()
    {
        final Set<String> expected = new HashSet<>(Arrays.asList("ABC", "BAC", "ACB", "BCA", "CBA", "CAB"));

        final Set<String> permutations = Ex13_Permutations.calcPermutations("ABC");

        assertAll(() -> assertEquals(6, permutations.size()), () -> assertEquals(expected, permutations));
    }

    // Schritt 2:
    // ##########

    @ParameterizedTest
    @MethodSource("providePermutations")
    void testSimplePermutations(String input, List<String> expectedPermutations)
    {
        final Set<String> expectedPermutationsAsSet = new HashSet<>(expectedPermutations);

        final Set<String> permutations = Ex13_Permutations.calcPermutations(input);

        assertEquals(expectedPermutationsAsSet, permutations);
    }

    private static Stream<Arguments> providePermutations()
    {
        return Stream.of(Arguments.of("A", Arrays.asList("A")), 
                         Arguments.of("AB", Arrays.asList("AB", "BA")),
                         Arguments.of("ABC", Arrays.asList("ABC", "BAC", "ACB", "BCA", "CBA", "CAB")));
    }

    @Test
    void testCalcPermutationsFor0123456789_JUnit5()
    {
        final String input = "0123456789";
        final int expectedSizeBasedOnFaculty = MathUtils.fac(input.length());

        final Set<String> permutations = Ex13_Permutations.calcPermutations(input);

        final long countWithSameLength = permutations.stream().filter(str -> str.length() == input.length()).count();

        // prüfe zunächst, ob die Anzahl stimmt 
        // prüfe dann, ob alle die gleiche Länge haben        
        assertAll(() -> assertEquals(expectedSizeBasedOnFaculty, permutations.size()),
                  () -> assertEquals(expectedSizeBasedOnFaculty, countWithSameLength));
    }

    @Test
    void testCalcPermutationsForAACAA_JUnit5()
    {
        final String input = "AAACA";

        final Set<String> expected = new HashSet<>(Arrays.asList(input, "AAACA", "AAAAC", "ACAAA", "AACAA", "CAAAA"));

        final int expectedSizeBasedOnFaculty = calcPermutationCountConcerningDuplicates(input);

        final Set<String> permutations = Ex13_Permutations.calcPermutations(input);

        assertAll(() -> assertEquals(expectedSizeBasedOnFaculty, permutations.size()),
                  () -> assertEquals(expected, permutations));
    }

    private int calcPermutationCountConcerningDuplicates(final String input)
    {
        final int sizeBasedOnFaculty = MathUtils.fac(input.length());
        final int duplicatesSizeBasedOnFaculty = Math.max(1, MathUtils.fac(countDuplicates(input)));
        
        return sizeBasedOnFaculty / duplicatesSizeBasedOnFaculty;
    }

    private int countDuplicates(final String input)
    {
        int duplicateCount = 0;
        final Set<Character> chars = new HashSet<>();
        for (int i = 0; i < input.length(); i++)
        {
            final char current = input.charAt(i);

            if (chars.contains(current))
            {
                duplicateCount++;
            }
            else
            {
                chars.add(current);
            }
        }
        return duplicateCount > 0 ? duplicateCount + 1 : 0;
    }
}
