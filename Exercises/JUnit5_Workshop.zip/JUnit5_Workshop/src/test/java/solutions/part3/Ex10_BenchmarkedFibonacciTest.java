package solutions.part3;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTimeout;
import static org.junit.jupiter.api.Assertions.assertTimeoutPreemptively;

import java.time.Duration;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.api.function.ThrowingSupplier;

import utils.FibonacciCalculator;

/**
 * Beispielprogramm für den Workshop "JUnit 5"
 * 
 * @author Michael Inden
 * 
 * Copyright 2019 by Michael Inden 
 */
@ExtendWith(Ex06_BenchmarkExtension.class)
class Ex10_BenchmarkedFibonacciTest
{   
    @Test
    void testFibRecWithBigNumber()
    {
        long value = FibonacciCalculator.fibRec(47);
        
        assertEquals(2971215073L, value);
    }
    
    @Test
    void testFibRecWithBigNumber_Timeout()
    {
        assertTimeoutPreemptively(Duration.ofSeconds(2), () -> FibonacciCalculator.fibRec(47));
    }       
    
    @Test
    void testCalcFib47_With_Timeout_And_Result()
    {
        // Provide result of calculation independently of time out
        ThrowingSupplier<Long> action = () -> {
            long result = FibonacciCalculator.fibRec(47);
            
            if (2971215073L == result)
                System.out.println("RESULT IS CORRECT");

            return result;
        };
        
        Long value = assertTimeout(Duration.ofSeconds(2), action);

        assertEquals(2971215073L, value);
    }
    
    @Test
    void testCalcFib47_With_Timeout_And_Result_Pre()
    {
        // Provide result of calculation independently of time out
        ThrowingSupplier<Long> action = () -> {
            long result = FibonacciCalculator.fibRec(47);
            
            // Dies wird bei Timeout niemals ausgeführt
            if (2971215073L == result)
                System.out.println("RESULT IS CORRECT");

            return result;
        };
        
        Long value = assertTimeoutPreemptively(Duration.ofSeconds(2), action);

        assertEquals(2971215073L, value);
    }
}
