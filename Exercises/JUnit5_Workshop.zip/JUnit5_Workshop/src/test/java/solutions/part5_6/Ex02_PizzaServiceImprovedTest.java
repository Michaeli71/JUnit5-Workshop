package solutions.part5_6;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

import exercises.part5_6.SmsNotificationService;

/**
 * Beispielprogramm für den Workshop "JUnit 5"
 * 
 * @author Michael Inden
 * 
 * Copyright 2019 by Michael Inden 
 */
public class Ex02_PizzaServiceImprovedTest
{
    @Test
    public void orderPizza_should_send_sms()
    {
        // Arrange
        final StubNotificationService stub = new StubNotificationService();
        final Ex02_PizzaServiceImproved service = new Ex02_PizzaServiceImproved()
        {
            @Override
            protected SmsNotificationService getNotificationService()
            {
                return stub;
            }
        };

        // Act
        service.orderPizza("Diavolo");
        service.orderPizza("Surprise");

        // Assert  
        assertTrue(stub.getMessages().contains(Ex02_PizzaServiceImproved.createNotificationMsg("Diavolo")));
        assertThat(stub.getMessages()).contains(Ex02_PizzaServiceImproved.createNotificationMsg("Surprise"));
        assertThat(stub.getMessages()).containsExactlyInAnyOrder(Ex02_PizzaServiceImproved.createNotificationMsg("Diavolo"), 
                                                                 Ex02_PizzaServiceImproved.createNotificationMsg("Surprise"));
    }
    
    // Bonus mit Mockito
    
    @Test
    public void orderPizza_should_send_sms_mockito_based()
    {
        // Arrange
        final SmsNotificationService mockSmsService = Mockito.mock(SmsNotificationService.class);
        final Ex02_PizzaServiceImproved service = new Ex02_PizzaServiceImproved()
        {
            @Override
            protected SmsNotificationService getNotificationService()
            {
                return mockSmsService;
            }
        };

        // Act
        service.orderPizza("Diavolo");
        service.orderPizza("Surprise");
        //service.orderPizza("OF_THE_DAY");

        // Assert
        /*
        Mockito.verify(mockSmsService).notify(Ex02_PizzaServiceImproved.createNotificationMsg("Diavolo"));
        Mockito.verify(mockSmsService).notify(Ex02_PizzaServiceImproved.createNotificationMsg("Surprise"));
        */
        //Mockito.verifyNoMoreInteractions(mockSmsService);        
        Mockito.verify(mockSmsService, Mockito.times(2)).notify(Mockito.anyString());
    }
}
