package solutions.part5_6;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

import java.time.LocalDate;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import exercises.part5_6.Arabic2RomanConverter;
import exercises.part5_6.Ex06_DateInRomanCharsService;

/**
 * Beispielprogramm für den Workshop "JUnit 5"
 * 
 * @author Michael Inden
 * 
 * Copyright 2019 by Michael Inden 
 */
class Ex06_DateInRomanCharsServiceTest
{
    @InjectMocks
    private Ex06_DateInRomanCharsService service;

    @Mock
    private Arabic2RomanConverter   converter;

    @BeforeEach
    void setUp()
    {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    void testServiceCallForCertainDate() throws Exception
    {
        LocalDate date = LocalDate.of(1971, 2, 7);

        when(converter.convert(7)).thenReturn("VII");
        when(converter.convert(2)).thenReturn("II");
        when(converter.convert(1971)).thenReturn("MCMLXXI");

        assertEquals("VII-II-MCMLXXI", service.getRomanDate(date));
        // Demo, dass andere AUfrufe "null" liefern
        //assertEquals("VII-II-MCMLXXI", service.getRomanDate(LocalDate.of(1979, 7, 14)));
    }
}