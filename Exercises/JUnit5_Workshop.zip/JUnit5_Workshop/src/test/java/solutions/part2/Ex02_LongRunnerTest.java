package solutions.part2;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTimeout;
import static org.junit.jupiter.api.Assertions.assertTimeoutPreemptively;

import java.time.Duration;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.ThrowingSupplier;

import exercises.part2.Ex02_LongRunner;

/**
 * Beispielprogramm für den Workshop "JUnit 5"
 * 
 * @author Michael Inden
 * 
 * Copyright 2019 by Michael Inden 
 */
class Ex02_LongRunnerTest
{
    @Test
    public void testCalcFib45() throws Exception
    {
     // Provide result of calculation if with in time out
        ThrowingSupplier<Long> action = () -> Ex02_LongRunner.calcFib45();
        
        Long value = assertTimeout(Duration.ofSeconds(10), 
                                   action);
                
        assertEquals(1134903170, value);
    }

    @Test
    public void testCalcFib30() throws Exception
    {
        // Provide result of calculation if with in time out
        ThrowingSupplier<Long> action = () -> Ex02_LongRunner.calcFib30();
        
        Long value = assertTimeoutPreemptively(Duration.ofSeconds(1), 
                                               action);
        
        assertEquals(832040, value);
    }
    
    @Test
    public void testToUpper() throws Exception
    {
        final String expected = "HELLO JUGS BERN";
        
        final String actual = Ex02_LongRunner.toUpper("hello JUGS bern");
        
        // use lambda for message generation
        assertEquals(expected, actual, () -> Ex02_LongRunner.createErrorMessage("JUGS"));
    }

}
