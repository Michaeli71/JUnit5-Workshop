package solutions.part7_8;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

import exercises.part7_8.FahrpreisRechner;

/**
 * Beispielprogramm für den Workshop "JUnit 5"
 * 
 * @author Michael Inden
 * 
 * Copyright 2019 by Michael Inden 
 */
public class Ex06_FahrpreisRechnerTest 
{
	private static final int grundpreis = 3_50;
	private static final int centProKM = 2_10;
	
	@Test
	public void TF1()
	{
		final int preis = FahrpreisRechner.fahrpreis(grundpreis, centProKM, 60, true, true, false);
		
		assertEquals(14_286, preis);
	}
	
	@Test
	public void TF2()
	{
		final int preis = FahrpreisRechner.fahrpreis(grundpreis, centProKM, 60, true, false, false);
		
		assertEquals(13_986, preis);
	}
	
	// --------------------------------

	@Test
	public void TF1_improved()
	{
		final int preis = FahrpreisRechner.fahrpreis(grundpreis, centProKM, 60, nachts(), mitGepäck(), keinFeiertag());
		
		assertEquals(14_286, preis);
	}

	@Test
	public void TF2_improved()
	{
		final int preis = FahrpreisRechner.fahrpreis(grundpreis, centProKM, 60, nachts(), ohneGepäck(), keinFeiertag());
		
		assertEquals(13_986, preis);
	}

	private boolean mitGepäck() {
		return true;
	}

	private boolean nachts() {
		return true;
	}
	
	private boolean ohneGepäck() {
		return false;
	}

	private boolean amTag() {
		return false;
	}
	
    private boolean amFeiertag()
    {
        return true;
    }
    
    private boolean keinFeiertag()
    {
        return false;
    }
	
	// --------------------------------

	// ...
	
	@Test
	public void TF3_improved()
	{
		final int preis = FahrpreisRechner.fahrpreis(grundpreis, centProKM, 5, amTag(), mitGepäck(), keinFeiertag());
		
		assertEquals(1_700, preis);
	}

	@Test
	public void T4_improved()
	{
		final int preis = FahrpreisRechner.fahrpreis(grundpreis, centProKM, 5, amTag(), ohneGepäck(), keinFeiertag());
		
		assertEquals(1_400, preis);
	}
}
