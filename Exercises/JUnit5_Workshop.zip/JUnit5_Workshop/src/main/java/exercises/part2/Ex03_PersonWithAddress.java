package exercises.part2;

import java.time.LocalDate;

/**
 * Beispielprogramm für den Workshop "JUnit 5"
 * 
 * @author Michael Inden
 * 
 * Copyright 2019 by Michael Inden 
 */
public class Ex03_PersonWithAddress
{
    // public just to keep the example short
    public final String    name;

    public final LocalDate dateOfBirth;

    public final String    city;
    public final String    country;

    public Ex03_PersonWithAddress(String name, LocalDate dateOfBirth, String city, String country)
    {
        this.name = name;
        this.dateOfBirth = dateOfBirth;
        this.city = city;
        this.country = country;
    }
    
    public static Ex03_PersonWithAddress createZurichLocated(final String name, LocalDate dateOfBith)
    {
        return new Ex03_PersonWithAddress("Mike", dateOfBith, "Zürich", "Swizerland");
    }
    
    public static Ex03_PersonWithAddress createKielLocated(final String name, LocalDate dateOfBith)
    {
        return new Ex03_PersonWithAddress(name, dateOfBith, "Zürich", "Switzerland");
    }
}