package exercises.part2;

import static utils.FibonacciCalculator.fibRec;

/**
 * Beispielprogramm für den Workshop "JUnit 5"
 * 
 * @author Michael Inden
 * 
 * Copyright 2019 by Michael Inden 
 */
public class Ex02_LongRunner
{
    public static long calcFib45()
    {
        return fibRec(45);
    }

    public static long calcFib30()
    {
        return fibRec(30);
    }
    
    public static String toUpper(final String input)
    {
        return input.toUpperCase();
    }
    
    public static String createErrorMessage(String info)
    {
        try
        {
            Thread.sleep(7_000);
        }
        catch (InterruptedException ignored)
        {
        }

        return info + info;
    }
}
