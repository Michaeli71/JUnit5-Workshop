package exercises.part7_8;

import java.util.HashMap;
import java.util.Map;

/**
 * Beispielprogramm für den Workshop "JUnit 5"
 * 
 * @author Michael Inden
 * 
 * Copyright 2019 by Michael Inden 
 */
public class Ex02_StudyGroup
{
    private final Map<Integer, Ex02_Student> students = new HashMap<>();

    public void addStudent(Ex02_Student student)
    {
        students.put(student.getId(), student);
    }

    public Ex02_Student getStudentById(int id)
    {
        return students.get(id);
    }

    public void removeStudent(int id)
    {
        students.remove(id);
    }

    public void clear()
    {
        students.clear();
    }

    public int getGroupSize()
    {
        return students.size();
    }
}