package exercises.part3;

/**
 * Beispielprogramm für den Workshop "JUnit 5"
 * 
 * @author Michael Inden
 * 
 * Copyright 2019 by Michael Inden 
 */
public enum Discounts 
{
	NO_DISCOUNT(0), MEDIUM_DISCOUNT(4), HIGH_DISCOUNT(7);
	
	private final int value;
	
	private Discounts(int value)
	{
		this.value = value;
	}
	
	public int getDiscountValue()
	{
		return value;
	}	
}
