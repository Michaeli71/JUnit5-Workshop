package exercises.part3;

/**
 * Beispielprogramm für den Workshop "JUnit 5"
 * 
 * @author Michael Inden
 * 
 *         Copyright 2019 by Michael Inden
 */
public class Ex03_LeapYear
{
    public static void main(String[] args)
    {
        for (int year = 1900; year < 2021; year++)
        {
            if (isLeap(year))
            {
                System.out.println("year: " + year);
            }
        }
    }

    public static boolean isLeap(final int year)
    {
        final boolean everyFourthYear = year % 4 == 0;
        final boolean isSecular = year % 100 == 0;
        final boolean isSecularSpecial = isSecular && year % 400 == 0;

        return everyFourthYear && !isSecular || isSecularSpecial;
    }
}
