package utils;

/**
 * Beispielprogramm für den Workshop "JUnit 5"
 * 
 * @author Michael Inden
 * 
 * Copyright 2019 by Michael Inden 
 */
public class Adder
{
    public static int add(int a, int b)
    {
        int sum = a + b;
        return sum;
    }
}
