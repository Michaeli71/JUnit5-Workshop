package utils;

/**
 * Beispielprogramm für den Workshop "JUnit 5"
 * 
 * @author Michael Inden
 * 
 * Copyright 2019 by Michael Inden 
 */
public class PalindromeChecker
{
    public static void main(String[] args)
    {
        System.out.println(isPalindrome("Otto"));
        System.out.println(isPalindrome("ABCBA"));
        System.out.println(isPalindrome("ABCBD"));
    }

    public static boolean isPalindrome(String input)
    {
        char[] chars = input.toLowerCase().toCharArray();

        return isPalindrome(chars);
    }

    private static boolean isPalindrome(char[] chars)
    {
        int left = 0;
        int right = chars.length - 1;

        boolean isSameChar = true;
        while (left < right && isSameChar)
        {
            isSameChar = (chars[left] == chars[right]);
            left++;
            right--;
        }

        return isSameChar;
    }
}
