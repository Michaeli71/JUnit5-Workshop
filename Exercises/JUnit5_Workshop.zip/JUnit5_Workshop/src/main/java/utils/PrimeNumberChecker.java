package utils;

/**
 * Beispielprogramm für den Workshop "JUnit 5"
 * 
 * @author Michael Inden
 * 
 * Copyright 2019 by Michael Inden 
 */
public class PrimeNumberChecker
{
    public static boolean isPrime(final Integer potenitallyPrimeNumber)
    {
        // prüfe für alle Zahlen von 2 bis number / 2, ob diese einen Teiler darstellen
        for (int i = 2; i < (potenitallyPrimeNumber / 2); i++)
        {
            if (potenitallyPrimeNumber % i == 0)
            {
                return false;
            }
        }
        return true;
    }
}