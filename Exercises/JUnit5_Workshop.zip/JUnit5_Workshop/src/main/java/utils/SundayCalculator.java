package utils;

import java.time.DayOfWeek;
import java.time.LocalDate;
import java.util.List;
import java.util.function.Predicate;
import java.util.stream.Collectors;

/**
 * Beispielprogramm für den Workshop "JUnit 5"
 * 
 * @author Michael Inden
 * 
 * Copyright 2019 by Michael Inden 
 */
public class SundayCalculator
{
    public static List<LocalDate> allSundaysBetween(final LocalDate start, final LocalDate end)
    {
        final Predicate<LocalDate> isSunday = day -> day.getDayOfWeek() == DayOfWeek.SUNDAY;

        return start.datesUntil(end).filter(isSunday).collect(Collectors.toList());
    }
}
