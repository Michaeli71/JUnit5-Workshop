package utils;

/**
 * Beispielprogramm für den Workshop "JUnit 5"
 * 
 * @author Michael Inden
 * 
 * Copyright 2019 by Michael Inden 
 */
public class MathUtils
{
    public static Integer fac(int n)
    {
        if (n == 1)
            return 1;

        return n * fac(n - 1);
    }

    public static Integer fib(int n)
    {
        if (n == 1 || n == 2)
            return 1;

        return fib(n-1) + fib(n-2);
    }
    
    public static boolean isOdd(int n)
    {
       return n % 2 != 0; 
    }
    
    public static boolean isEven(int n)
    {
       return n % 2 == 0; 
    }

}
