package solutions.part5_6;

import exercises.part5_6.SmsNotificationService;

/**
 * Beispielprogramm für den Workshop "JUnit 5"
 * 
 * @author Michael Inden
 * 
 * Copyright 2019 by Michael Inden 
 */
public class Ex02_PizzaServiceImproved
{
    private final SmsNotificationService notificationService;

    public Ex02_PizzaServiceImproved()
    {
        notificationService = getNotificationService();
    }

    public void orderPizza(final String name)
    {
        notificationService.notify(createNotificationMsg(name));
    }

    protected SmsNotificationService getNotificationService()
    {
        return new SmsNotificationService();
    }

    public static String createNotificationMsg(final String name)
    {
        return "Pizza " + name + " wird in Kürze geliefert.";
    }
}
