package solutions.part7_8;

import java.util.Comparator;

/**
 * Beispielprogramm für den Workshop "JUnit 5"
 * 
 * @author Michael Inden
 * 
 * Copyright 2019 by Michael Inden 
 */
public class Ex01_VersionNumberComparator implements Comparator<String>
{
    // Algorithmus: Splitte die textuellen Versionnummern auf.
    // Durchlaufe dann die einzelnen element und vergleiche paarweise. 
    @Override
    public int compare(final String v1, final String v2)
    {
        String[] v1Numbers = v1.split("\\."); // Achtung: Reg-Ex, . macht jedes Zeichen!
        String[] v2Numbers = v2.split("\\.");

        int pos = 0;
        int compareResult = 0;
        while (pos < v1Numbers.length && pos < v2Numbers.length && compareResult == 0)
        {
            int currentV1 = Integer.valueOf(v1Numbers[pos]);
            int currentV2 = Integer.valueOf(v2Numbers[pos]);

            compareResult = Integer.compare(currentV1, currentV2);
            pos++;
        }

        if (compareResult == 0)
        {
            return Integer.compare(v1Numbers.length, v2Numbers.length);
        }

        return compareResult;
    }
}
