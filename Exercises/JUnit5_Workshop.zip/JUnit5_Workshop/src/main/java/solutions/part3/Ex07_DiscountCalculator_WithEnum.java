package solutions.part3;

import exercises.part3.Discounts;

/**
 * Beispielprogramm für den Workshop "JUnit 5"
 * 
 * @author Michael Inden
 * 
 * Copyright 2019 by Michael Inden 
 */
public class Ex07_DiscountCalculator_WithEnum 
{
	public Discounts calcDiscount(final int count)
	{
		if(count < 0)
			throw new IllegalArgumentException("Count must be positive");
		
		if (count < 50)
			return Discounts.NO_DISCOUNT;
		if (count >= 50 && count <= 1000)
			return Discounts.MEDIUM_DISCOUNT;
		if (count > 1000)
			return Discounts.HIGH_DISCOUNT;

		throw new IllegalStateException("programming problem: should never " +
	                  "reach this line. value " + count + " is not handled!");
	}
}