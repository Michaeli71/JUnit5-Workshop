package solutions.part3;

import java.util.Stack;

/**
 * Beispielprogramm für den Workshop "JUnit 5"
 * 
 * @author Michael Inden
 * 
 * Copyright 2019 by Michael Inden 
 */
public class Ex02_MatchingBracesChecker
{
    static boolean checkMatchingBraces(final String input)
    {
        // uneven/odd input length can't be a valid combination of braces
        if (input.length() % 2 != 0)
            return false;

        final Stack<Character> openingParens = new Stack<>();

        for (int i = 0; i < input.length(); i++)
        {
            char currentChar = input.charAt(i);
            if (isOpeningParenthesis(currentChar))
            {
                openingParens.push(currentChar);
            }
            else if (isClosingParenthesis(currentChar))
            {
                if (openingParens.isEmpty())
                {
                    // closing before opening
                    return false;
                }

                char lastOpeningParens = openingParens.pop();

                if (!isMatchingParenthesisPair(lastOpeningParens, currentChar))
                {
                    // mismatch in parenthesis
                    return false;
                }
            }
            else
            {
                // invalid char
                return false;
            }
        }

        return openingParens.isEmpty();
    }

    // Helpers
    static boolean isOpeningParenthesis(char ch)
    {
        return ch == '(' || ch == '[' || ch == '{';
    }

    static boolean isClosingParenthesis(char ch)
    {
        return ch == ')' || ch == ']' || ch == '}';
    }

    static boolean isMatchingParenthesisPair(char opening, char closing)
    {
        return (opening == '(' && closing == ')') || (opening == '[' && closing == ']')
               || (opening == '{' && closing == '}');
    }
}
