package solutions.part3;

/**
 * Beispielprogramm für den Workshop "JUnit 5"
 * 
 * @author Michael Inden
 * 
 * Copyright 2019 by Michael Inden 
 */
public class Ex07_DiscountCalculator 
{
	public int calcDiscount_UNREACHABLE(final int count)
	{
		if(count < 0)
			throw new IllegalArgumentException("Count must be positive");

		if (count < 50)
			return 0;
		if (count >= 50 && count <= 1000)
			return 4;
		if (count > 1000)
			return 7;

		throw new IllegalStateException("programming problem: should never " +
	                  "reach this line. value " + count + " is not handled!");
	}
	
    // obige Schreibweise finde ich schöner
    public int calcDiscount(final int count)
    {
        if (count < 0)
            throw new IllegalArgumentException("Count must be positive");

        if (count < 50)
            return 0;
        else if (count <= 1000)
            return 4;
        else
            return 7;
    }
}