package mutation;

import java.util.Arrays;
import java.util.List;

/**
 * Beispielprogramm im Rahmen des Workshops der JAVA PROFI ACADEMY
 * 
 * @author Michael Inden
 * 
 * Copyright 2020 by Michael Inden 
 */
public class ListCalcExampleNoTest
{
    public static int findFirstDuplicate(final List<Integer> values)
    {
        int[] valuesAsArray = values.stream().mapToInt(i -> i).toArray();

        Arrays.sort(valuesAsArray);

        int dup = -1;
        for (int i = 1; i < valuesAsArray.length; i++)
        {
            if (valuesAsArray[i] == valuesAsArray[i - 1])
            {
                dup = valuesAsArray[i];
                break;
            }
        }
        return dup;
    }

    public static void main(final String[] args)
    {
        List<Integer> numbers = List.of(1, 2, 3, 3, 4, 4, 5, 6, 7);

        int repeated = findFirstDuplicate(numbers);
        System.out.println(repeated);
    }
}