package mutation;

// https://www.oracle.com/corporate/features/mutation-testing.html
class SpecialCounter 
{
	private int count;

	public void countIfHundredOrAbove(final int value) 
	{
		if (value >= 100) 
		{
			count++;
		}
	}

	public void reset() 
	{
		count = 0;
	}

	public int currentCount() 
	{
		return count;
	}
}