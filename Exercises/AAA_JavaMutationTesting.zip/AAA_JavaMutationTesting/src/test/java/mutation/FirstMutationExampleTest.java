package mutation;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

/**
 * Beispielprogramm im Rahmen des Workshops der JAVA PROFI ACADEMY
 * 
 * @author Michael Inden
 * 
 * Copyright 2020 by Michael Inden 
 */
public class FirstMutationExampleTest 
{
	@Test
	void testBuilPositivedMessage()
	{
		assertEquals("almost positive", FirstMutationExample.buildMessage(42));
	}
	
	@Test
	void testBuildNegativeMessage()
	{
		assertEquals("negative", FirstMutationExample.buildMessage(-777));
	}
}
